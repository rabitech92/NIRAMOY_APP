import 'package:flutter_test/flutter_test.dart';
import 'package:tutorbondhu/models/models.dart';

void main() {
  test('Tutor parses JSON and splits subjects', () {
    final t = Tutor.fromJson({'id': 1, 'name': 'Rahim', 'subjects': 'Math, Physics, ', 'hourlyRate': 600, 'experienceYears': 6});
    expect(t.subjectList, ['Math', 'Physics']);
    expect(t.location, '');
    expect(t.hourlyRate, 600);
  });

  test('TuitionRequest parses JSON', () {
    final r = TuitionRequest.fromJson({
      'id': 5, 'studentName': 'A', 'tutorName': 'B', 'subject': 'Math',
      'status': 'PENDING', 'createdAt': '2026-11-16T10:30:00',
    });
    expect(r.status, 'PENDING');
    expect(r.message, '');
    expect(r.createdAt.year, 2026);
  });

  test('AppUser roles', () {
    final u = AppUser.fromJson({'id': 1, 'name': 'X', 'email': 'x@y.z', 'role': 'ADMIN'});
    expect(u.isAdmin, isTrue);
    expect(u.isTutor, isFalse);
  });
}
