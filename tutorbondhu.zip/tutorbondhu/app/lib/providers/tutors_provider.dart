import '../core/api_client.dart';
import '../core/safe_notifier.dart';
import '../models/models.dart';

class TutorsProvider extends SafeNotifier {
  TutorsProvider(this._api);
  final ApiClient _api;
  static const _size = 15;

  List<Tutor> items = [];
  bool loading = true, loadingMore = false, hasMore = true;
  String? error;
  String subject = '', location = '';
  int _page = 0;
  int _req = 0; // ignores responses that arrive out of order

  Future<void> refresh({String? subject, String? location}) async {
    this.subject = subject ?? this.subject;
    this.location = location ?? this.location;
    final id = ++_req;
    _page = 0;
    loading = true;
    loadingMore = false;
    error = null;
    notifyListeners();
    try {
      final r = await _fetch(0);
      if (id != _req) return;
      items = r.$1;
      hasMore = r.$2;
    } catch (e) {
      if (id != _req) return;
      error = e.toString();
    }
    loading = false;
    notifyListeners();
  }

  Future<void> loadMore() async {
    if (loading || loadingMore || !hasMore) return;
    loadingMore = true;
    notifyListeners();
    final id = _req;
    try {
      final r = await _fetch(_page + 1);
      if (id == _req) {
        _page++;
        items = [...items, ...r.$1];
        hasMore = r.$2;
      }
    } catch (_) {}
    if (id == _req) loadingMore = false;
    notifyListeners();
  }

  Future<(List<Tutor>, bool)> _fetch(int page) async {
    final r = await _api.request('GET', '/tutors',
        query: {'subject': subject, 'location': location, 'page': '$page', 'size': '$_size'});
    final list = (r['content'] as List).map((e) => Tutor.fromJson(e)).toList();
    return (list, r['last'] != true);
  }
}
