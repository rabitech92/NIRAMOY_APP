import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import '../core/api_client.dart';
import '../models/models.dart';

class AuthProvider extends ChangeNotifier {
  AuthProvider() {
    api.onUnauthorized = () {
      if (user != null) {
        notice = 'Your session expired. Please log in again.';
        logout();
      }
    };
  }

  final api = ApiClient();
  final _store = const FlutterSecureStorage();
  AppUser? user;
  bool loading = true;
  String? notice;

  Future<void> init() async {
    try {
      final t = await _store.read(key: 'token');
      final u = await _store.read(key: 'user');
      if (t != null && u != null) {
        api.token = t;
        user = AppUser.fromJson(jsonDecode(u));
      }
    } catch (_) {}
    loading = false;
    notifyListeners();
  }

  Future<void> _save(Map<String, dynamic> r) async {
    api.token = r['token'];
    user = AppUser.fromJson(r['user']);
    notice = null;
    await _store.write(key: 'token', value: api.token);
    await _store.write(key: 'user', value: jsonEncode(r['user']));
    notifyListeners();
  }

  Future<void> login(String email, String password) async =>
      _save(await api.request('POST', '/auth/login', body: {'email': email, 'password': password}));

  Future<void> register(String name, String email, String phone, String password, String role) async =>
      _save(await api.request('POST', '/auth/register',
          body: {'name': name, 'email': email, 'phone': phone, 'password': password, 'role': role}));

  Future<void> logout() async {
    api.token = null;
    user = null;
    await _store.deleteAll();
    notifyListeners();
  }
}
