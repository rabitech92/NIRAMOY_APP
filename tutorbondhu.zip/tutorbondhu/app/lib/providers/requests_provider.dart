import '../core/api_client.dart';
import '../core/safe_notifier.dart';
import '../models/models.dart';

class RequestsProvider extends SafeNotifier {
  RequestsProvider(this._api);
  final ApiClient _api;

  List<TuitionRequest> items = [];
  bool loading = true;
  String? error;

  int get pendingCount => items.where((r) => r.status == 'PENDING').length;

  Future<void> load() async {
    error = null;
    try {
      final r = await _api.request('GET', '/requests/mine');
      items = (r as List).map((e) => TuitionRequest.fromJson(e)).toList();
    } catch (e) {
      error = e.toString();
    }
    loading = false;
    notifyListeners();
  }

  Future<void> create(int tutorId, String subject, String message) async {
    await _api.request('POST', '/requests', body: {'tutorId': tutorId, 'subject': subject, 'message': message});
    await load();
  }

  /// Optimistic update with rollback on failure.
  Future<void> setStatus(TuitionRequest r, String status) async {
    final old = r.status;
    r.status = status;
    notifyListeners();
    try {
      await _api.request('PATCH', '/requests/${r.id}/status', body: {'status': status});
    } catch (_) {
      r.status = old;
      notifyListeners();
      rethrow;
    }
  }
}
