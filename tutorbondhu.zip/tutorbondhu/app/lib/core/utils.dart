import 'dart:async';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

void showError(BuildContext context, Object e) => _snack(context, e.toString(), error: true);
void showInfo(BuildContext context, String msg) => _snack(context, msg);

void _snack(BuildContext context, String msg, {bool error = false}) {
  final cs = Theme.of(context).colorScheme;
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(
      content: Text(msg, style: TextStyle(color: error ? cs.onError : cs.onInverseSurface)),
      backgroundColor: error ? cs.error : cs.inverseSurface,
      behavior: SnackBarBehavior.floating,
    ));
}

String fmtDate(DateTime d) => DateFormat('d MMM yyyy, h:mm a').format(d);

class Debouncer {
  final Duration delay;
  Timer? _t;
  Debouncer([this.delay = const Duration(milliseconds: 400)]);
  void run(VoidCallback f) {
    _t?.cancel();
    _t = Timer(delay, f);
  }

  void dispose() => _t?.cancel();
}

Future<bool> confirmDialog(BuildContext context, String title, String text, {String action = 'Confirm', bool danger = false}) async =>
    await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(title),
        content: Text(text),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          FilledButton(
            style: danger ? FilledButton.styleFrom(backgroundColor: Colors.red) : null,
            onPressed: () => Navigator.pop(ctx, true),
            child: Text(action),
          ),
        ],
      ),
    ) ??
    false;
