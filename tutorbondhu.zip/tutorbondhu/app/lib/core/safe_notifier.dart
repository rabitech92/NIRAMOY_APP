import 'package:flutter/foundation.dart';

/// ChangeNotifier that ignores notifications after dispose (e.g. async work finishing after logout).
class SafeNotifier extends ChangeNotifier {
  bool _disposed = false;
  @override
  void dispose() {
    _disposed = true;
    super.dispose();
  }

  @override
  void notifyListeners() {
    if (!_disposed) super.notifyListeners();
  }
}
