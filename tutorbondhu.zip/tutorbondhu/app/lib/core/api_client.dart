import 'dart:convert';
import 'package:http/http.dart' as http;
import 'config.dart';

class ApiException implements Exception {
  final String message;
  ApiException(this.message);
  @override
  String toString() => message;
}

class ApiClient {
  String? token;

  /// Called when the server rejects a stored token (expired / blocked account).
  void Function()? onUnauthorized;

  Future<dynamic> request(String method, String path,
      {Map<String, dynamic>? body, Map<String, String>? query}) async {
    final uri = Uri.parse('${AppConfig.baseUrl}$path')
        .replace(queryParameters: query?.isEmpty ?? true ? null : query);
    try {
      final req = http.Request(method, uri)
        ..headers['Content-Type'] = 'application/json'
        ..headers.addAll({if (token != null) 'Authorization': 'Bearer $token'});
      if (body != null) req.body = jsonEncode(body);
      final res = await http.Response.fromStream(
          await req.send().timeout(const Duration(seconds: 15)));
      final data = res.body.isEmpty ? null : jsonDecode(utf8.decode(res.bodyBytes));
      if (res.statusCode >= 200 && res.statusCode < 300) return data;
      if (res.statusCode == 401 && token != null) {
        onUnauthorized?.call();
        throw ApiException('Session expired. Please log in again.');
      }
      throw ApiException(data is Map && data['message'] != null
          ? data['message'].toString()
          : 'Request failed (${res.statusCode})');
    } on ApiException {
      rethrow;
    } catch (_) {
      throw ApiException('Network error. Please check your connection.');
    }
  }
}
