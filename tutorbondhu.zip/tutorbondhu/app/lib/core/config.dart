class AppConfig {
  // Android emulator -> host machine. For a real phone use your PC's LAN IP,
  // or pass: flutter run --dart-define=API_URL=http://192.168.x.x:8080/api
  static const baseUrl =
      String.fromEnvironment('API_URL', defaultValue: 'http://10.0.2.2:8080/api');
}
