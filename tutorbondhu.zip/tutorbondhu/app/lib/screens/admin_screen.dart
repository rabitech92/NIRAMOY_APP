import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/utils.dart';
import '../core/widgets.dart';
import '../providers/auth_provider.dart';

class AdminHomeScreen extends StatefulWidget {
  const AdminHomeScreen({super.key});
  @override
  State<AdminHomeScreen> createState() => _AdminHomeScreenState();
}

class _AdminHomeScreenState extends State<AdminHomeScreen> {
  int _i = 0;

  @override
  Widget build(BuildContext context) {
    const titles = ['Dashboard', 'Users', 'Tuition Requests'];
    return Scaffold(
      appBar: AppBar(
        title: Text('Admin • ${titles[_i]}'),
        actions: [IconButton(tooltip: 'Logout', icon: const Icon(Icons.logout), onPressed: context.read<AuthProvider>().logout)],
      ),
      body: IndexedStack(index: _i, children: [AdminDashboard(key: ValueKey(_i == 0)), const AdminUsers(), const AdminRequests()]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _i,
        onDestinationSelected: (v) => setState(() => _i = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.dashboard_outlined), label: 'Dashboard'),
          NavigationDestination(icon: Icon(Icons.people_outline), label: 'Users'),
          NavigationDestination(icon: Icon(Icons.assignment_outlined), label: 'Requests'),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------- Dashboard
class AdminDashboard extends StatefulWidget {
  const AdminDashboard({super.key});
  @override
  State<AdminDashboard> createState() => _AdminDashboardState();
}

class _AdminDashboardState extends State<AdminDashboard> {
  Map<String, dynamic>? _s;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      _s = await context.read<AuthProvider>().api.request('GET', '/admin/stats');
    } catch (e) {
      if (mounted) showError(context, e);
    }
    if (mounted) setState(() => _loading = false);
  }

  Widget _card(String label, String key, IconData icon, Color color) => AppCard(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Container(padding: const EdgeInsets.all(8), decoration: BoxDecoration(color: color.withAlpha(34), borderRadius: BorderRadius.circular(10)), child: Icon(icon, color: color, size: 20)),
            Text('${_s?[key] ?? 0}', style: const TextStyle(fontSize: 30, fontWeight: FontWeight.bold)),
            Text(label, style: TextStyle(color: Colors.grey.shade700)),
          ]),
        ),
      );

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator());
    return RefreshIndicator(
      onRefresh: _load,
      child: GridView.count(
        padding: const EdgeInsets.all(16),
        crossAxisCount: 2, mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: 1.3,
        children: [
          _card('Total users', 'totalUsers', Icons.groups, Colors.teal),
          _card('Students', 'students', Icons.person, Colors.blue),
          _card('Tutors', 'tutors', Icons.school, Colors.indigo),
          _card('Blocked users', 'blockedUsers', Icons.block, Colors.red),
          _card('All requests', 'totalRequests', Icons.assignment, Colors.purple),
          _card('Pending', 'pending', Icons.hourglass_bottom, Colors.orange),
          _card('Accepted', 'accepted', Icons.check_circle, Colors.green),
          _card('Rejected', 'rejected', Icons.cancel, Colors.redAccent),
        ],
      ),
    );
  }
}

Future<bool> _confirm(BuildContext context, String text) async =>
    await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Are you sure?'),
        content: Text(text),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          FilledButton(style: FilledButton.styleFrom(backgroundColor: Colors.red), onPressed: () => Navigator.pop(ctx, true), child: const Text('Delete')),
        ],
      ),
    ) ?? false;

// -------------------------------------------------------------------- Users
class AdminUsers extends StatefulWidget {
  const AdminUsers({super.key});
  @override
  State<AdminUsers> createState() => _AdminUsersState();
}

class _AdminUsersState extends State<AdminUsers> {
  final _q = TextEditingController();
  String? _role;
  List<dynamic> _items = [];
  int _page = 0;
  bool _loading = true, _last = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load({bool reset = true}) async {
    if (reset) {
      _page = 0;
      setState(() => _loading = true);
    }
    try {
      final r = await context.read<AuthProvider>().api.request('GET', '/admin/users',
          query: {'q': _q.text.trim(), 'page': '$_page', 'size': '30', if (_role != null) 'role': _role!});
      final c = r['content'] as List;
      _items = reset ? c : [..._items, ...c];
      _last = r['last'] == true;
    } catch (e) {
      if (mounted) showError(context, e);
    }
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _toggle(Map u) async {
    try {
      final r = await context.read<AuthProvider>().api.request('PATCH', '/admin/users/${u['id']}/enabled', body: {'enabled': !(u['enabled'] as bool)});
      setState(() => _items = _items.map((e) => e['id'] == u['id'] ? r : e).toList());
    } catch (e) {
      if (mounted) showError(context, e);
    }
  }

  Future<void> _delete(Map u) async {
    if (!await _confirm(context, 'Delete ${u['name']} and all their data?')) return;
    try {
      await context.read<AuthProvider>().api.request('DELETE', '/admin/users/${u['id']}');
      setState(() => _items = _items.where((e) => e['id'] != u['id']).toList());
    } catch (e) {
      if (mounted) showError(context, e);
    }
  }

  Widget _filter(String label, String? value) => Padding(
        padding: const EdgeInsets.only(right: 8),
        child: ChoiceChip(label: Text(label), selected: _role == value, onSelected: (_) { _role = value; _load(); }),
      );

  @override
  Widget build(BuildContext context) => Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
          child: TextField(controller: _q, textInputAction: TextInputAction.search, onSubmitted: (_) => _load(),
              decoration: const InputDecoration(hintText: 'Search name or email', prefixIcon: Icon(Icons.search), isDense: true)),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Row(children: [_filter('All', null), _filter('Students', 'STUDENT'), _filter('Tutors', 'TUTOR'), _filter('Admins', 'ADMIN')]),
        ),
        Expanded(
          child: _loading
              ? const SkeletonList()
              : RefreshIndicator(
                  onRefresh: _load,
                  child: ListView.builder(
                    itemCount: _items.length + (_last ? 0 : 1),
                    itemBuilder: (_, i) {
                      if (i == _items.length) {
                        return TextButton(onPressed: () { _page++; _load(reset: false); }, child: const Text('Load more'));
                      }
                      final u = _items[i] as Map;
                      final on = u['enabled'] as bool;
                      final admin = u['role'] == 'ADMIN';
                      return ListTile(
                        leading: CircleAvatar(backgroundColor: on ? null : Colors.red.shade100, child: Text('${u['name']}'[0].toUpperCase())),
                        title: Text('${u['name']}${on ? '' : '  (blocked)'}', style: TextStyle(fontWeight: FontWeight.w600, color: on ? null : Colors.red)),
                        subtitle: Text('${u['email']}\n${u['role']}  •  ${u['phone'] ?? '-'}'),
                        isThreeLine: true,
                        trailing: admin
                            ? null
                            : PopupMenuButton<String>(
                                onSelected: (v) => v == 'toggle' ? _toggle(u) : _delete(u),
                                itemBuilder: (_) => [
                                  PopupMenuItem(value: 'toggle', child: Text(on ? 'Block user' : 'Unblock user')),
                                  const PopupMenuItem(value: 'delete', child: Text('Delete user')),
                                ],
                              ),
                      );
                    },
                  ),
                ),
        ),
      ]);
}

// ----------------------------------------------------------------- Requests
class AdminRequests extends StatefulWidget {
  const AdminRequests({super.key});
  @override
  State<AdminRequests> createState() => _AdminRequestsState();
}

class _AdminRequestsState extends State<AdminRequests> {
  String? _status;
  List<dynamic> _items = [];
  int _page = 0;
  bool _loading = true, _last = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load({bool reset = true}) async {
    if (reset) {
      _page = 0;
      setState(() => _loading = true);
    }
    try {
      final r = await context.read<AuthProvider>().api.request('GET', '/admin/requests',
          query: {'page': '$_page', 'size': '30', if (_status != null) 'status': _status!});
      final c = r['content'] as List;
      _items = reset ? c : [..._items, ...c];
      _last = r['last'] == true;
    } catch (e) {
      if (mounted) showError(context, e);
    }
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _delete(Map r) async {
    if (!await _confirm(context, 'Delete this request?')) return;
    try {
      await context.read<AuthProvider>().api.request('DELETE', '/admin/requests/${r['id']}');
      setState(() => _items = _items.where((e) => e['id'] != r['id']).toList());
    } catch (e) {
      if (mounted) showError(context, e);
    }
  }

  Color _color(String s) => s == 'ACCEPTED' ? Colors.green : s == 'REJECTED' ? Colors.red : Colors.orange;

  Widget _filter(String label, String? value) => Padding(
        padding: const EdgeInsets.only(right: 8),
        child: ChoiceChip(label: Text(label), selected: _status == value, onSelected: (_) { _status = value; _load(); }),
      );

  @override
  Widget build(BuildContext context) => Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
          child: SingleChildScrollView(scrollDirection: Axis.horizontal, child: Row(children: [_filter('All', null), _filter('Pending', 'PENDING'), _filter('Accepted', 'ACCEPTED'), _filter('Rejected', 'REJECTED')])),
        ),
        Expanded(
          child: _loading
              ? const SkeletonList()
              : RefreshIndicator(
                  onRefresh: _load,
                  child: _items.isEmpty
                      ? ListView(children: const [SizedBox(height: 120), Center(child: Text('No requests'))])
                      : ListView.builder(
                          padding: const EdgeInsets.all(16),
                          itemCount: _items.length + (_last ? 0 : 1),
                          itemBuilder: (_, i) {
                            if (i == _items.length) {
                              return TextButton(onPressed: () { _page++; _load(reset: false); }, child: const Text('Load more'));
                            }
                            final r = _items[i] as Map;
                            final st = r['status'] as String;
                            return AppCard(
                              margin: const EdgeInsets.only(bottom: 12),
                              child: Padding(
                                padding: const EdgeInsets.all(14),
                                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                  Row(children: [
                                    Expanded(child: Text('${r['studentName']}  →  ${r['tutorName']}', style: const TextStyle(fontWeight: FontWeight.w600))),
                                    StatusChip(st),
                                    IconButton(icon: const Icon(Icons.delete_outline, color: Colors.red), onPressed: () => _delete(r)),
                                  ]),
                                  Text('Subject: ${r['subject']}'),
                                  if ((r['message'] ?? '').toString().isNotEmpty) Text('${r['message']}', style: TextStyle(color: Colors.grey.shade700)),
                                  const SizedBox(height: 4),
                                  Text('${r['createdAt']}'.replaceFirst('T', ' ').substring(0, 16), style: const TextStyle(fontSize: 12, color: Colors.grey)),
                                ]),
                              ),
                            );
                          }),
                ),
        ),
      ]);
}
