import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/utils.dart';
import '../core/widgets.dart';
import '../models/models.dart';
import '../providers/auth_provider.dart';
import '../providers/requests_provider.dart';

class TutorDetailScreen extends StatelessWidget {
  final Tutor tutor;
  final RequestsProvider requests;
  const TutorDetailScreen({super.key, required this.tutor, required this.requests});

  Future<void> _openSheet(BuildContext context) async {
    final sent = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (_) => _RequestSheet(tutor: tutor, requests: requests),
    );
    if (sent == true && context.mounted) showInfo(context, 'Request sent! You will see the reply under Requests.');
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final isStudent = !context.read<AuthProvider>().user!.isTutor;
    return Scaffold(
      appBar: appBar(context, 'Tutor profile'),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        AppCard(
          padding: const EdgeInsets.all(20),
          child: Column(children: [
            Avatar(name: tutor.name, size: 88, heroTag: 'tutor-${tutor.id}'),
            const SizedBox(height: 12),
            Text(tutor.name, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
            const SizedBox(height: 10),
            Wrap(alignment: WrapAlignment.center, spacing: 6, runSpacing: 6, children: tutor.subjectList.map((s) => Tag(s)).toList()),
          ]),
        ),
        const SizedBox(height: 12),
        Row(children: [
          Expanded(child: _Stat(Icons.workspace_premium_outlined, '${tutor.experienceYears} yrs', 'Experience')),
          const SizedBox(width: 10),
          Expanded(child: _Stat(Icons.payments_outlined, '৳${tutor.hourlyRate}', 'Per hour')),
          const SizedBox(width: 10),
          Expanded(child: _Stat(Icons.place_outlined, tutor.location.isEmpty ? '-' : tutor.location, 'Area')),
        ]),
        const SizedBox(height: 12),
        AppCard(
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('About', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
            const SizedBox(height: 8),
            Text(tutor.bio.isEmpty ? 'This tutor has not added a bio yet.' : tutor.bio, style: TextStyle(height: 1.5, color: cs.onSurfaceVariant)),
          ]),
        ),
      ]),
      bottomNavigationBar: isStudent
          ? SafeArea(
              child: Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(color: cs.surface, border: Border(top: BorderSide(color: cs.outlineVariant))),
                child: LoadingButton(label: 'Request tuition', icon: Icons.send_rounded, onPressed: () => _openSheet(context)),
              ),
            )
          : null,
    );
  }
}

class _Stat extends StatelessWidget {
  final IconData icon;
  final String value, label;
  const _Stat(this.icon, this.value, this.label);

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return AppCard(
      padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 8),
      child: Column(children: [
        Icon(icon, color: cs.primary),
        const SizedBox(height: 6),
        Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800)),
        Text(label, style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant)),
      ]),
    );
  }
}

class _RequestSheet extends StatefulWidget {
  final Tutor tutor;
  final RequestsProvider requests;
  const _RequestSheet({required this.tutor, required this.requests});
  @override
  State<_RequestSheet> createState() => _RequestSheetState();
}

class _RequestSheetState extends State<_RequestSheet> {
  final _key = GlobalKey<FormState>();
  late final _subject = TextEditingController(text: widget.tutor.subjectList.isNotEmpty ? widget.tutor.subjectList.first : '');
  final _msg = TextEditingController();
  bool _busy = false;

  @override
  void dispose() {
    _subject.dispose();
    _msg.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_key.currentState!.validate()) return;
    setState(() => _busy = true);
    try {
      await widget.requests.create(widget.tutor.id, _subject.text.trim(), _msg.text.trim());
      if (mounted) Navigator.pop(context, true);
    } catch (e) {
      if (mounted) {
        setState(() => _busy = false);
        showError(context, e);
      }
    }
  }

  @override
  Widget build(BuildContext context) => SingleChildScrollView(
        padding: EdgeInsets.fromLTRB(20, 0, 20, 20 + MediaQuery.of(context).viewInsets.bottom),
        child: Form(
          key: _key,
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Request tuition from ${widget.tutor.name}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
            const SizedBox(height: 14),
            if (widget.tutor.subjectList.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: Wrap(spacing: 8, runSpacing: 4, children: widget.tutor.subjectList.map((s) => ActionChip(label: Text(s), onPressed: () => setState(() => _subject.text = s))).toList()),
              ),
            AppTextField(controller: _subject, label: 'Subject', icon: Icons.menu_book_outlined, action: TextInputAction.next, validator: (v) => (v == null || v.trim().isEmpty) ? 'Enter a subject' : null),
            const SizedBox(height: 12),
            AppTextField(controller: _msg, label: 'Message (optional)', hint: 'Your class, schedule, goals...', maxLines: 3, maxLength: 300),
            const SizedBox(height: 8),
            LoadingButton(label: 'Send request', busy: _busy, onPressed: _submit),
          ]),
        ),
      );
}
