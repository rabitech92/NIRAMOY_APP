import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/utils.dart';
import '../core/widgets.dart';
import '../providers/auth_provider.dart';
import 'edit_profile_screen.dart';

class ProfileTab extends StatelessWidget {
  const ProfileTab({super.key});

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final u = auth.user!;
    final cs = Theme.of(context).colorScheme;
    return ListView(padding: const EdgeInsets.all(16), children: [
      AppCard(
        padding: const EdgeInsets.all(20),
        child: Row(children: [
          Avatar(name: u.name, size: 64),
          const SizedBox(width: 16),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(u.name, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
              const SizedBox(height: 2),
              Text(u.email, style: TextStyle(color: cs.onSurfaceVariant)),
              if ((u.phone ?? '').isNotEmpty) Text(u.phone!, style: TextStyle(color: cs.onSurfaceVariant)),
              const SizedBox(height: 8),
              Tag(u.isTutor ? 'Tutor' : 'Student'),
            ]),
          ),
        ]),
      ),
      const SizedBox(height: 16),
      AppCard(
        child: Column(children: [
          if (u.isTutor)
            ListTile(
              leading: const Icon(Icons.edit_outlined),
              title: const Text('Edit tutor profile'),
              subtitle: const Text('Subjects, rate, location and bio'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const EditProfileScreen())),
            ),
          ListTile(
            leading: const Icon(Icons.info_outline),
            title: const Text('About TutorBondhu'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => showAboutDialog(context: context, applicationName: 'TutorBondhu', applicationVersion: '1.1.0'),
          ),
          ListTile(
            leading: Icon(Icons.logout, color: cs.error),
            title: Text('Log out', style: TextStyle(color: cs.error)),
            onTap: () async {
              if (await confirmDialog(context, 'Log out?', 'You will need to log in again.', action: 'Log out')) auth.logout();
            },
          ),
        ]),
      ),
    ]);
  }
}
