import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/utils.dart';
import '../core/widgets.dart';
import '../models/models.dart';
import '../providers/requests_provider.dart';
import '../providers/tutors_provider.dart';
import 'tutor_detail_screen.dart';

class TutorsTab extends StatefulWidget {
  const TutorsTab({super.key});
  @override
  State<TutorsTab> createState() => _TutorsTabState();
}

class _TutorsTabState extends State<TutorsTab> {
  final _subject = TextEditingController(), _area = TextEditingController();
  final _scroll = ScrollController();
  final _debounce = Debouncer();

  @override
  void initState() {
    super.initState();
    _scroll.addListener(() {
      if (_scroll.position.pixels > _scroll.position.maxScrollExtent - 300) {
        context.read<TutorsProvider>().loadMore();
      }
    });
  }

  @override
  void dispose() {
    _subject.dispose();
    _area.dispose();
    _scroll.dispose();
    _debounce.dispose();
    super.dispose();
  }

  void _search() => _debounce.run(() =>
      context.read<TutorsProvider>().refresh(subject: _subject.text.trim(), location: _area.text.trim()));

  @override
  Widget build(BuildContext context) {
    final p = context.watch<TutorsProvider>();
    return Column(children: [
      Padding(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
        child: Row(children: [
          Expanded(child: AppTextField(controller: _subject, label: 'Subject', icon: Icons.menu_book_outlined, action: TextInputAction.search, onChanged: (_) => _search())),
          const SizedBox(width: 10),
          Expanded(child: AppTextField(controller: _area, label: 'Area', icon: Icons.place_outlined, action: TextInputAction.search, onChanged: (_) => _search())),
        ]),
      ),
      Expanded(child: _body(p)),
    ]);
  }

  Widget _body(TutorsProvider p) {
    if (p.loading) return const SkeletonList();
    if (p.error != null && p.items.isEmpty) return ErrorState(message: p.error!, onRetry: p.refresh);
    return RefreshIndicator(
      onRefresh: p.refresh,
      child: p.items.isEmpty
          ? ListView(children: const [
              SizedBox(height: 80),
              EmptyState(icon: Icons.search_off, title: 'No tutors found', subtitle: 'Try a different subject or area.'),
            ])
          : ListView.builder(
              controller: _scroll,
              physics: const AlwaysScrollableScrollPhysics(),
              padding: const EdgeInsets.all(16),
              itemCount: p.items.length + (p.loadingMore ? 1 : 0),
              itemBuilder: (_, i) => i == p.items.length
                  ? const Padding(padding: EdgeInsets.all(16), child: Center(child: CircularProgressIndicator()))
                  : _TutorCard(p.items[i]),
            ),
    );
  }
}

class _TutorCard extends StatelessWidget {
  final Tutor t;
  const _TutorCard(this.t);

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final muted = TextStyle(fontSize: 12, color: cs.onSurfaceVariant);
    return AppCard(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      onTap: () {
        final requests = context.read<RequestsProvider>();
        Navigator.push(context, MaterialPageRoute(builder: (_) => TutorDetailScreen(tutor: t, requests: requests)));
      },
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Avatar(name: t.name, size: 52, heroTag: 'tutor-${t.id}'),
        const SizedBox(width: 12),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(t.name, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
            const SizedBox(height: 6),
            t.subjectList.isEmpty
                ? Text('Profile not completed yet', style: muted)
                : Wrap(spacing: 6, runSpacing: 6, children: t.subjectList.take(3).map((s) => Tag(s)).toList()),
            const SizedBox(height: 8),
            Row(children: [
              Icon(Icons.place_outlined, size: 14, color: cs.onSurfaceVariant),
              const SizedBox(width: 3),
              Flexible(child: Text(t.location.isEmpty ? 'Location not set' : t.location, maxLines: 1, overflow: TextOverflow.ellipsis, style: muted)),
              const SizedBox(width: 10),
              Icon(Icons.workspace_premium_outlined, size: 14, color: cs.onSurfaceVariant),
              const SizedBox(width: 3),
              Text('${t.experienceYears} yrs', style: muted),
            ]),
          ]),
        ),
        const SizedBox(width: 8),
        Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
          Text('৳${t.hourlyRate}', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 17, color: cs.primary)),
          Text('per hour', style: TextStyle(fontSize: 11, color: cs.onSurfaceVariant)),
        ]),
      ]),
    );
  }
}
