import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/widgets.dart';
import '../providers/auth_provider.dart';
import '../providers/requests_provider.dart';
import '../providers/tutors_provider.dart';
import 'profile_tab.dart';
import 'requests_tab.dart';
import 'tutors_tab.dart';

/// Providers live here so they are disposed (and state cleared) on logout.
class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final api = context.read<AuthProvider>().api;
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => TutorsProvider(api)..refresh()),
        ChangeNotifierProvider(create: (_) => RequestsProvider(api)..load()),
      ],
      child: const _Shell(),
    );
  }
}

class _Shell extends StatefulWidget {
  const _Shell();
  @override
  State<_Shell> createState() => _ShellState();
}

class _ShellState extends State<_Shell> {
  int _i = 0;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final isTutor = context.read<AuthProvider>().user!.isTutor;
    final pending = isTutor ? context.watch<RequestsProvider>().pendingCount : 0;
    const titles = ['Find Tutors', 'My Requests', 'Profile'];
    return Scaffold(
      appBar: appBar(context, titles[_i]),
      body: IndexedStack(index: _i, children: const [TutorsTab(), RequestsTab(), ProfileTab()]),
      bottomNavigationBar: NavigationBar(
        backgroundColor: cs.surface,
        surfaceTintColor: Colors.transparent,
        indicatorColor: cs.primaryContainer,
        selectedIndex: _i,
        onDestinationSelected: (v) => setState(() => _i = v),
        destinations: [
          const NavigationDestination(icon: Icon(Icons.search), selectedIcon: Icon(Icons.search), label: 'Tutors'),
          NavigationDestination(
            icon: Badge(label: Text('$pending'), isLabelVisible: pending > 0, child: const Icon(Icons.assignment_outlined)),
            selectedIcon: Badge(label: Text('$pending'), isLabelVisible: pending > 0, child: const Icon(Icons.assignment)),
            label: 'Requests',
          ),
          const NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }
}
