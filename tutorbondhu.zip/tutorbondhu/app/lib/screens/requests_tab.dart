import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/utils.dart';
import '../core/widgets.dart';
import '../models/models.dart';
import '../providers/auth_provider.dart';
import '../providers/requests_provider.dart';

class RequestsTab extends StatefulWidget {
  const RequestsTab({super.key});
  @override
  State<RequestsTab> createState() => _RequestsTabState();
}

class _RequestsTabState extends State<RequestsTab> {
  String? _filter;

  Future<void> _set(TuitionRequest r, String status) async {
    try {
      await context.read<RequestsProvider>().setStatus(r, status);
    } catch (e) {
      if (mounted) showError(context, e);
    }
  }

  Widget _chip(String label, String? value) => Padding(
        padding: const EdgeInsets.only(right: 8),
        child: ChoiceChip(label: Text(label), selected: _filter == value, onSelected: (_) => setState(() => _filter = value)),
      );

  @override
  Widget build(BuildContext context) {
    final p = context.watch<RequestsProvider>();
    final isTutor = context.read<AuthProvider>().user!.isTutor;
    if (p.loading) return const SkeletonList();
    if (p.error != null && p.items.isEmpty) return ErrorState(message: p.error!, onRetry: p.load);
    final list = _filter == null ? p.items : p.items.where((r) => r.status == _filter).toList();
    return Column(children: [
      Padding(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
        child: SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(children: [_chip('All', null), _chip('Pending', 'PENDING'), _chip('Accepted', 'ACCEPTED'), _chip('Rejected', 'REJECTED')]),
        ),
      ),
      Expanded(
        child: RefreshIndicator(
          onRefresh: p.load,
          child: list.isEmpty
              ? ListView(children: [
                  const SizedBox(height: 80),
                  EmptyState(
                    icon: Icons.assignment_outlined,
                    title: 'No requests yet',
                    subtitle: isTutor ? 'Requests from students will appear here.' : 'Find a tutor and send your first request.',
                  ),
                ])
              : ListView.builder(
                  physics: const AlwaysScrollableScrollPhysics(),
                  padding: const EdgeInsets.all(16),
                  itemCount: list.length,
                  itemBuilder: (_, i) => _RequestCard(list[i], isTutor: isTutor, onSet: _set),
                ),
        ),
      ),
    ]);
  }
}

class _RequestCard extends StatelessWidget {
  final TuitionRequest r;
  final bool isTutor;
  final Future<void> Function(TuitionRequest, String) onSet;
  const _RequestCard(this.r, {required this.isTutor, required this.onSet});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final name = isTutor ? r.studentName : r.tutorName;
    return AppCard(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Avatar(name: name, size: 40),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(name, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
              Text(isTutor ? 'Student' : 'Tutor', style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant)),
            ]),
          ),
          StatusChip(r.status),
        ]),
        const SizedBox(height: 12),
        Row(children: [
          Icon(Icons.menu_book_outlined, size: 16, color: cs.onSurfaceVariant),
          const SizedBox(width: 6),
          Expanded(child: Text(r.subject, style: const TextStyle(fontWeight: FontWeight.w600))),
        ]),
        if (r.message.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 6), child: Text(r.message, style: TextStyle(color: cs.onSurfaceVariant))),
        const SizedBox(height: 8),
        Text(fmtDate(r.createdAt), style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant)),
        if (isTutor && r.status == 'PENDING') ...[
          const SizedBox(height: 12),
          Row(children: [
            Expanded(child: FilledButton(onPressed: () => onSet(r, 'ACCEPTED'), child: const Text('Accept'))),
            const SizedBox(width: 10),
            Expanded(child: OutlinedButton(onPressed: () => onSet(r, 'REJECTED'), child: const Text('Reject'))),
          ]),
        ],
      ]),
    );
  }
}
