import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/api_client.dart';
import '../core/utils.dart';
import '../core/widgets.dart';
import '../providers/auth_provider.dart';

class EditProfileScreen extends StatefulWidget {
  const EditProfileScreen({super.key});
  @override
  State<EditProfileScreen> createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends State<EditProfileScreen> {
  final _key = GlobalKey<FormState>();
  final _subjects = TextEditingController(), _bio = TextEditingController(), _location = TextEditingController(),
      _rate = TextEditingController(text: '0'), _exp = TextEditingController(text: '0');
  bool _loading = true, _saving = false;
  String? _error;

  ApiClient get _api => context.read<AuthProvider>().api;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    for (final c in [_subjects, _bio, _location, _rate, _exp]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _load() async {
    setState(() { _loading = true; _error = null; });
    try {
      final r = await _api.request('GET', '/tutors/me');
      _subjects.text = r['subjects'] ?? '';
      _bio.text = r['bio'] ?? '';
      _location.text = r['location'] ?? '';
      _rate.text = '${r['hourlyRate'] ?? 0}';
      _exp.text = '${r['experienceYears'] ?? 0}';
    } catch (e) {
      _error = e.toString();
    }
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _save() async {
    FocusScope.of(context).unfocus();
    if (!_key.currentState!.validate()) return;
    setState(() => _saving = true);
    try {
      await _api.request('PUT', '/tutors/me', body: {
        'subjects': _subjects.text.trim(), 'bio': _bio.text.trim(), 'location': _location.text.trim(),
        'hourlyRate': int.parse(_rate.text), 'experienceYears': int.parse(_exp.text),
      });
      if (mounted) {
        showInfo(context, 'Profile saved');
        Navigator.pop(context);
      }
    } catch (e) {
      if (mounted) {
        setState(() => _saving = false);
        showError(context, e);
      }
    }
  }

  String? _number(String? v) => (v == null || int.tryParse(v) == null || int.parse(v) < 0) ? 'Enter a number' : null;

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: appBar(context, 'Edit profile'),
        body: _loading
            ? const Center(child: CircularProgressIndicator())
            : _error != null
                ? ErrorState(message: _error!, onRetry: _load)
                : Form(
                    key: _key,
                    child: ListView(padding: const EdgeInsets.all(16), children: [
                      AppTextField(controller: _subjects, label: 'Subjects', hint: 'Math, Physics, English', icon: Icons.menu_book_outlined, action: TextInputAction.next,
                          validator: (v) => (v == null || v.trim().isEmpty) ? 'Add at least one subject (comma separated)' : null),
                      const SizedBox(height: 14),
                      AppTextField(controller: _location, label: 'Area', hint: 'Dhanmondi, Dhaka', icon: Icons.place_outlined, action: TextInputAction.next),
                      const SizedBox(height: 14),
                      Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Expanded(child: AppTextField(controller: _rate, label: 'Rate (৳/hour)', type: TextInputType.number, action: TextInputAction.next, validator: _number)),
                        const SizedBox(width: 12),
                        Expanded(child: AppTextField(controller: _exp, label: 'Experience (yrs)', type: TextInputType.number, action: TextInputAction.next, validator: _number)),
                      ]),
                      const SizedBox(height: 14),
                      AppTextField(controller: _bio, label: 'About you', hint: 'Teaching style, qualifications, availability', maxLines: 5, maxLength: 1000),
                      const SizedBox(height: 8),
                      LoadingButton(label: 'Save profile', busy: _saving, onPressed: _save),
                    ]),
                  ),
      );
}
