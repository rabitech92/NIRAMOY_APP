import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/utils.dart';
import '../core/widgets.dart';
import '../providers/auth_provider.dart';

final _emailRe = RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$');
String? _required(String? v) => (v == null || v.trim().isEmpty) ? 'This field is required' : null;
String? _emailRule(String? v) => (v == null || !_emailRe.hasMatch(v.trim())) ? 'Enter a valid email address' : null;

class _AuthScaffold extends StatelessWidget {
  final String title, subtitle;
  final bool back;
  final List<Widget> children;
  const _AuthScaffold({required this.title, required this.subtitle, required this.children, this.back = false});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: back ? AppBar(backgroundColor: Colors.transparent, surfaceTintColor: Colors.transparent) : null,
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: EdgeInsets.fromLTRB(24, back ? 0 : 24, 24, 24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 440),
              child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                Center(
                  child: Container(
                    width: 64, height: 64,
                    decoration: BoxDecoration(color: cs.primary, borderRadius: BorderRadius.circular(20)),
                    child: Icon(Icons.school_rounded, color: cs.onPrimary, size: 34),
                  ),
                ),
                const SizedBox(height: 16),
                Text(title, textAlign: TextAlign.center, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w800)),
                const SizedBox(height: 6),
                Text(subtitle, textAlign: TextAlign.center, style: TextStyle(color: cs.onSurfaceVariant)),
                const SizedBox(height: 28),
                ...children,
              ]),
            ),
          ),
        ),
      ),
    );
  }
}

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _key = GlobalKey<FormState>();
  final _email = TextEditingController(), _pw = TextEditingController();
  bool _busy = false, _hide = true;

  @override
  void dispose() {
    _email.dispose();
    _pw.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    FocusScope.of(context).unfocus();
    if (!_key.currentState!.validate()) return;
    setState(() => _busy = true);
    try {
      await context.read<AuthProvider>().login(_email.text.trim(), _pw.text);
    } catch (e) {
      if (mounted) showError(context, e);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final notice = context.watch<AuthProvider>().notice;
    return _AuthScaffold(
      title: 'Welcome back',
      subtitle: 'Log in to find the right tutor',
      children: [
        if (notice != null)
          Container(
            margin: const EdgeInsets.only(bottom: 16),
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(color: cs.errorContainer, borderRadius: BorderRadius.circular(12)),
            child: Text(notice, style: TextStyle(color: cs.onErrorContainer)),
          ),
        Form(
          key: _key,
          child: Column(children: [
            AppTextField(controller: _email, label: 'Email', icon: Icons.email_outlined, type: TextInputType.emailAddress,
                action: TextInputAction.next, validator: _emailRule, autofill: const [AutofillHints.email]),
            const SizedBox(height: 14),
            AppTextField(
              controller: _pw, label: 'Password', icon: Icons.lock_outline, obscure: _hide,
              action: TextInputAction.done, validator: _required, onSubmitted: (_) => _submit(),
              autofill: const [AutofillHints.password],
              suffix: IconButton(
                tooltip: _hide ? 'Show password' : 'Hide password',
                icon: Icon(_hide ? Icons.visibility_outlined : Icons.visibility_off_outlined),
                onPressed: () => setState(() => _hide = !_hide),
              ),
            ),
          ]),
        ),
        const SizedBox(height: 22),
        LoadingButton(label: 'Login', busy: _busy, onPressed: _submit),
        const SizedBox(height: 8),
        TextButton(
          onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const RegisterScreen())),
          child: const Text("Don't have an account? Sign up"),
        ),
      ],
    );
  }
}

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});
  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _key = GlobalKey<FormState>();
  final _name = TextEditingController(), _email = TextEditingController(), _phone = TextEditingController(),
      _pw = TextEditingController(), _pw2 = TextEditingController();
  String _role = 'STUDENT';
  bool _busy = false;

  @override
  void dispose() {
    for (final c in [_name, _email, _phone, _pw, _pw2]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _submit() async {
    FocusScope.of(context).unfocus();
    if (!_key.currentState!.validate()) return;
    setState(() => _busy = true);
    try {
      await context.read<AuthProvider>().register(_name.text.trim(), _email.text.trim(), _phone.text.trim(), _pw.text, _role);
      if (mounted) Navigator.of(context).popUntil((r) => r.isFirst);
    } catch (e) {
      if (mounted) showError(context, e);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => _AuthScaffold(
        back: true,
        title: 'Create account',
        subtitle: 'Join TutorBondhu in a minute',
        children: [
          Row(children: [
            Expanded(child: _RoleCard(icon: Icons.person_outline, title: 'Student', subtitle: 'Find tutors', selected: _role == 'STUDENT', onTap: () => setState(() => _role = 'STUDENT'))),
            const SizedBox(width: 12),
            Expanded(child: _RoleCard(icon: Icons.school_outlined, title: 'Tutor', subtitle: 'Offer tuition', selected: _role == 'TUTOR', onTap: () => setState(() => _role = 'TUTOR'))),
          ]),
          const SizedBox(height: 18),
          Form(
            key: _key,
            child: Column(children: [
              AppTextField(controller: _name, label: 'Full name', icon: Icons.badge_outlined, action: TextInputAction.next, validator: _required, autofill: const [AutofillHints.name]),
              const SizedBox(height: 14),
              AppTextField(controller: _email, label: 'Email', icon: Icons.email_outlined, type: TextInputType.emailAddress, action: TextInputAction.next, validator: _emailRule, autofill: const [AutofillHints.email]),
              const SizedBox(height: 14),
              AppTextField(controller: _phone, label: 'Phone (optional)', icon: Icons.phone_outlined, type: TextInputType.phone, action: TextInputAction.next),
              const SizedBox(height: 14),
              AppTextField(controller: _pw, label: 'Password', icon: Icons.lock_outline, obscure: true, action: TextInputAction.next,
                  validator: (v) => (v == null || v.length < 6) ? 'At least 6 characters' : null),
              const SizedBox(height: 14),
              AppTextField(controller: _pw2, label: 'Confirm password', icon: Icons.lock_outline, obscure: true, action: TextInputAction.done,
                  onSubmitted: (_) => _submit(), validator: (v) => v != _pw.text ? 'Passwords do not match' : null),
            ]),
          ),
          const SizedBox(height: 22),
          LoadingButton(label: 'Create account', busy: _busy, onPressed: _submit),
        ],
      );
}

class _RoleCard extends StatelessWidget {
  final IconData icon;
  final String title, subtitle;
  final bool selected;
  final VoidCallback onTap;
  const _RoleCard({required this.icon, required this.title, required this.subtitle, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Semantics(
      button: true, selected: selected, label: '$title: $subtitle',
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 16),
          decoration: BoxDecoration(
            color: selected ? cs.primaryContainer : cs.surface,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: selected ? cs.primary : cs.outlineVariant, width: selected ? 2 : 1),
          ),
          child: Column(children: [
            Icon(icon, color: selected ? cs.primary : cs.onSurfaceVariant, size: 28),
            const SizedBox(height: 6),
            Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
            Text(subtitle, style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant)),
          ]),
        ),
      ),
    );
  }
}
