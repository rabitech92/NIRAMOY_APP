import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'core/theme.dart';
import 'providers/auth_provider.dart';
import 'screens/admin_screen.dart';
import 'screens/auth_screens.dart';
import 'screens/home_screen.dart';

void main() => runApp(ChangeNotifierProvider(
    create: (_) => AuthProvider()..init(), child: const TutorBondhuApp()));

class TutorBondhuApp extends StatelessWidget {
  const TutorBondhuApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'TutorBondhu',
        debugShowCheckedModeBanner: false,
        theme: buildTheme(Brightness.light),
        darkTheme: buildTheme(Brightness.dark),
        themeMode: ThemeMode.system,
        home: Consumer<AuthProvider>(
          builder: (_, auth, __) {
            if (auth.loading) return const _Splash();
            if (auth.user == null) return const LoginScreen();
            return auth.user!.isAdmin ? const AdminHomeScreen() : const HomeScreen();
          },
        ),
      );
}

class _Splash extends StatelessWidget {
  const _Splash();
  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      body: Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(
            width: 72, height: 72,
            decoration: BoxDecoration(color: cs.primary, borderRadius: BorderRadius.circular(22)),
            child: Icon(Icons.school_rounded, color: cs.onPrimary, size: 40),
          ),
          const SizedBox(height: 16),
          const Text('TutorBondhu', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
        ]),
      ),
    );
  }
}
