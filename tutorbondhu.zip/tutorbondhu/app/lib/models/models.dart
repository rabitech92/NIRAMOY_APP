class AppUser {
  final int id;
  final String name, email, role;
  final String? phone;
  AppUser({required this.id, required this.name, required this.email, required this.role, this.phone});
  bool get isTutor => role == 'TUTOR';
  bool get isAdmin => role == 'ADMIN';
  factory AppUser.fromJson(Map<String, dynamic> j) =>
      AppUser(id: j['id'], name: j['name'], email: j['email'], role: j['role'], phone: j['phone']);
}

class Tutor {
  final int id, hourlyRate, experienceYears;
  final String name, subjects, bio, location;
  Tutor.fromJson(Map<String, dynamic> j)
      : id = j['id'],
        name = j['name'] ?? '',
        subjects = j['subjects'] ?? '',
        bio = j['bio'] ?? '',
        location = j['location'] ?? '',
        hourlyRate = j['hourlyRate'] ?? 0,
        experienceYears = j['experienceYears'] ?? 0;

  List<String> get subjectList =>
      subjects.split(',').map((s) => s.trim()).where((s) => s.isNotEmpty).toList();
}

class TuitionRequest {
  final int id;
  final String studentName, tutorName, subject, message;
  String status;
  final DateTime createdAt;
  TuitionRequest.fromJson(Map<String, dynamic> j)
      : id = j['id'],
        studentName = j['studentName'] ?? '',
        tutorName = j['tutorName'] ?? '',
        subject = j['subject'] ?? '',
        message = j['message'] ?? '',
        status = j['status'],
        createdAt = DateTime.parse(j['createdAt']);
}
