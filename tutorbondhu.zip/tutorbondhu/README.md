# TutorBondhu

Tutor–student marketplace. `backend/` = Spring Boot 3 (Java 17) + MySQL + JWT. `app/` = Flutter.

## 1. Backend
Requires JDK 17, Maven 3.9+, MySQL 8 running on localhost:3306.
The `tutorbondhu` database is created automatically on first run.

    cd backend
    # recommended: keep secrets out of code
    export DB_USER=root DB_PASS=Admin123 JWT_SECRET='<long-random-32+-char-string>'
    mvn spring-boot:run

API runs at http://localhost:8080/api

## 2. Flutter app
Requires Flutter 3.22+.

    cd app
    flutter create --org com.tutorbondhu --project-name tutorbondhu .   # generates android/ios folders
    flutter pub get
    flutter run                        # Android emulator -> http://10.0.2.2:8080/api
    flutter run --dart-define=API_URL=http://<PC-LAN-IP>:8080/api   # real phone

Android only: add `android:usesCleartextTraffic="true"` to `<application>` in
`android/app/src/main/AndroidManifest.xml` (plain HTTP for dev), and `<uses-permission android:name="android.permission.INTERNET"/>` for release builds.
Also set `minSdkVersion 18` or higher (flutter_secure_storage) if your template defaults lower.

## Admin panel
On first start the backend creates an admin account (change it via env vars before real use):

    ADMIN_EMAIL=admin@tutorbondhu.com   ADMIN_PASSWORD=Admin@12345

Login with these in the app and it opens the Admin panel automatically:
dashboard stats, all users (search, filter by role, block/unblock, delete) and all tuition requests (filter by status, delete).

## API
| Method | Path | Auth | Notes |
|---|---|---|---|
| POST | /api/auth/register | – | name, email, password, phone, role (STUDENT/TUTOR) |
| POST | /api/auth/login | – | returns JWT |
| GET | /api/tutors?subject=&location=&page=&size= | – | paged search |
| GET | /api/tutors/{id} | – | |
| GET/PUT | /api/tutors/me | TUTOR | own profile |
| GET | /api/admin/stats | ADMIN | counts |
| GET | /api/admin/users?q=&role=&page= | ADMIN | all users |
| PATCH | /api/admin/users/{id}/enabled | ADMIN | block / unblock |
| DELETE | /api/admin/users/{id} | ADMIN | removes user + related data |
| GET | /api/admin/requests?status=&page= | ADMIN | all requests |
| DELETE | /api/admin/requests/{id} | ADMIN | |
| POST | /api/requests | STUDENT | tutorId, subject, message |
| GET | /api/requests/mine | any | student: sent; tutor: received |
| PATCH | /api/requests/{id}/status | TUTOR | ACCEPTED / REJECTED |

Send `Authorization: Bearer <token>`.

## Flutter app structure (v1.1)
    lib/core/       theme, API client (401 auto-logout), shared widgets, utils
    lib/models/     data models
    lib/providers/  auth, tutors (pagination + debounced search), requests (optimistic updates)
    lib/screens/    auth, home shell, tutors, requests, profile, tutor detail, edit profile, admin
Highlights: light/dark theme, skeleton loaders, empty/error states with retry, infinite scroll,
pull-to-refresh, form validation, request bottom sheet, pending-request badge for tutors, session-expiry handling.
Fonts load via google_fonts (needs internet on first run; falls back to system font offline).
Run tests: `flutter test`   Static analysis: `flutter analyze`
