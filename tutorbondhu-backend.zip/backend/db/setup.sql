-- Optional: the app creates the database automatically (createDatabaseIfNotExist=true).
CREATE DATABASE IF NOT EXISTS tutorbondhu CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
