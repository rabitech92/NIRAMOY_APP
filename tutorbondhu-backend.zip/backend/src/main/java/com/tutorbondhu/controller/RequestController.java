package com.tutorbondhu.controller;

import static com.tutorbondhu.dto.Dtos.*;

import com.tutorbondhu.service.RequestService;
import jakarta.validation.Valid;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController @RequestMapping("/api/requests") @RequiredArgsConstructor
public class RequestController {
    private final RequestService service;

    @PostMapping @ResponseStatus(HttpStatus.CREATED)
    public RequestDto create(Authentication a, @Valid @RequestBody RequestCreate r) { return service.create(a.getName(), r); }

    @GetMapping("/mine")
    public List<RequestDto> mine(Authentication a) { return service.mine(a.getName()); }

    @PatchMapping("/{id}/status")
    public RequestDto status(Authentication a, @PathVariable Long id, @Valid @RequestBody StatusUpdate s) {
        return service.updateStatus(a.getName(), id, s.status());
    }
}
