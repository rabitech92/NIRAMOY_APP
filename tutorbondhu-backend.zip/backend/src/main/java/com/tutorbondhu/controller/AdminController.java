package com.tutorbondhu.controller;

import static com.tutorbondhu.dto.Dtos.*;

import com.tutorbondhu.model.RequestStatus;
import com.tutorbondhu.model.Role;
import com.tutorbondhu.service.AdminService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController @RequestMapping("/api/admin") @RequiredArgsConstructor
public class AdminController {
    private final AdminService admin;

    @GetMapping("/stats") public StatsDto stats() { return admin.stats(); }

    @GetMapping("/users")
    public Page<AdminUserDto> users(@RequestParam(defaultValue = "") String q, @RequestParam(required = false) Role role,
                                    @RequestParam(defaultValue = "0") int page, @RequestParam(defaultValue = "30") int size) {
        return admin.users(q, role, page, size);
    }

    @PatchMapping("/users/{id}/enabled")
    public AdminUserDto enabled(@PathVariable Long id, @RequestBody EnabledUpdate u) { return admin.setEnabled(id, u.enabled()); }

    @DeleteMapping("/users/{id}") @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteUser(@PathVariable Long id) { admin.deleteUser(id); }

    @GetMapping("/requests")
    public Page<RequestDto> requests(@RequestParam(required = false) RequestStatus status,
                                     @RequestParam(defaultValue = "0") int page, @RequestParam(defaultValue = "30") int size) {
        return admin.requests(status, page, size);
    }

    @DeleteMapping("/requests/{id}") @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteRequest(@PathVariable Long id) { admin.deleteRequest(id); }
}
