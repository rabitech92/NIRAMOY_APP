package com.tutorbondhu.controller;

import static com.tutorbondhu.dto.Dtos.*;

import com.tutorbondhu.service.TutorService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController @RequestMapping("/api/tutors") @RequiredArgsConstructor
public class TutorController {
    private final TutorService service;

    @GetMapping
    public Page<TutorDto> search(@RequestParam(defaultValue = "") String subject,
                                 @RequestParam(defaultValue = "") String location,
                                 @RequestParam(defaultValue = "0") int page,
                                 @RequestParam(defaultValue = "20") int size) {
        return service.search(subject, location, page, size);
    }

    @GetMapping("/{id}") public TutorDto get(@PathVariable Long id) { return service.get(id); }

    @GetMapping("/me") public TutorDto me(Authentication a) { return service.me(a.getName()); }

    @PutMapping("/me") public TutorDto update(Authentication a, @Valid @RequestBody TutorUpdate u) { return service.update(a.getName(), u); }
}
