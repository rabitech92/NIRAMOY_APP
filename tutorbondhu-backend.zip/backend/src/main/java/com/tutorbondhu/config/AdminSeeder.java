package com.tutorbondhu.config;

import com.tutorbondhu.model.Role;
import com.tutorbondhu.model.User;
import com.tutorbondhu.repository.UserRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

/** Creates the first admin account on startup if it does not exist. */
@Component
public class AdminSeeder implements CommandLineRunner {
    private final UserRepository users;
    private final PasswordEncoder encoder;
    private final String email, password;

    public AdminSeeder(UserRepository users, PasswordEncoder encoder,
                       @Value("${app.admin.email}") String email, @Value("${app.admin.password}") String password) {
        this.users = users; this.encoder = encoder; this.email = email.toLowerCase(); this.password = password;
    }

    @Override
    public void run(String... args) {
        if (users.existsByEmail(email)) return;
        User u = new User();
        u.setName("Administrator"); u.setEmail(email); u.setPassword(encoder.encode(password)); u.setRole(Role.ADMIN);
        users.save(u);
    }
}
