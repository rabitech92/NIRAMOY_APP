package com.tutorbondhu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TutorBondhuApplication {
    public static void main(String[] args) { SpringApplication.run(TutorBondhuApplication.class, args); }
}
