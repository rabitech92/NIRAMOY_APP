package com.tutorbondhu.repository;

import com.tutorbondhu.model.TuitionRequest;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TuitionRequestRepository extends JpaRepository<TuitionRequest, Long> {
    long countByStatus(com.tutorbondhu.model.RequestStatus status);
    org.springframework.data.domain.Page<TuitionRequest> findByStatus(com.tutorbondhu.model.RequestStatus status, org.springframework.data.domain.Pageable p);
    void deleteByStudentId(Long id);
    void deleteByTutorUserId(Long id);
    List<TuitionRequest> findByStudentEmailOrderByCreatedAtDesc(String email);
    List<TuitionRequest> findByTutorUserEmailOrderByCreatedAtDesc(String email);
}
