package com.tutorbondhu.repository;

import com.tutorbondhu.model.User;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByEmail(String email);
    boolean existsByEmail(String email);
    long countByRole(com.tutorbondhu.model.Role role);
    long countByEnabled(boolean enabled);

    @org.springframework.data.jpa.repository.Query("select u from User u where lower(u.name) like lower(concat('%', :q, '%')) or lower(u.email) like lower(concat('%', :q, '%'))")
    org.springframework.data.domain.Page<User> search(@org.springframework.data.repository.query.Param("q") String q, org.springframework.data.domain.Pageable p);

    @org.springframework.data.jpa.repository.Query("select u from User u where u.role = :role and (lower(u.name) like lower(concat('%', :q, '%')) or lower(u.email) like lower(concat('%', :q, '%')))")
    org.springframework.data.domain.Page<User> searchByRole(@org.springframework.data.repository.query.Param("q") String q, @org.springframework.data.repository.query.Param("role") com.tutorbondhu.model.Role role, org.springframework.data.domain.Pageable p);
}
