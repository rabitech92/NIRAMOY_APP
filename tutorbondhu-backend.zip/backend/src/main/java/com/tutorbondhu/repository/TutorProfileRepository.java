package com.tutorbondhu.repository;

import com.tutorbondhu.model.TutorProfile;
import java.util.Optional;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface TutorProfileRepository extends JpaRepository<TutorProfile, Long> {
    Optional<TutorProfile> findByUserEmail(String email);
    void deleteByUserId(Long userId);

    @Query("select t from TutorProfile t where lower(t.subjects) like lower(concat('%', :subject, '%')) " +
           "and lower(t.location) like lower(concat('%', :location, '%'))")
    Page<TutorProfile> search(@Param("subject") String subject, @Param("location") String location, Pageable pageable);
}
