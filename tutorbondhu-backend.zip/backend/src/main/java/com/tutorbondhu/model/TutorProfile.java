package com.tutorbondhu.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity @Table(name = "tutor_profiles") @Getter @Setter
public class TutorProfile {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @OneToOne(optional = false) @JoinColumn(name = "user_id", unique = true) private User user;
    private String subjects = "";
    @Column(length = 1000) private String bio = "";
    private int hourlyRate;
    private String location = "";
    private int experienceYears;
}
