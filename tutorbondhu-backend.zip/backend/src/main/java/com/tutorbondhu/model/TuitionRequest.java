package com.tutorbondhu.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import lombok.Getter;
import lombok.Setter;

@Entity @Table(name = "tuition_requests") @Getter @Setter
public class TuitionRequest {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @ManyToOne(optional = false) private User student;
    @ManyToOne(optional = false) private TutorProfile tutor;
    @Column(nullable = false) private String subject;
    @Column(length = 1000) private String message;
    @Enumerated(EnumType.STRING) private RequestStatus status = RequestStatus.PENDING;
    private LocalDateTime createdAt = LocalDateTime.now();
}
