package com.tutorbondhu.model;
public enum RequestStatus { PENDING, ACCEPTED, REJECTED }
