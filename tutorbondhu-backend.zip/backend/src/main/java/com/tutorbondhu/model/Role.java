package com.tutorbondhu.model;
public enum Role { STUDENT, TUTOR, ADMIN }
