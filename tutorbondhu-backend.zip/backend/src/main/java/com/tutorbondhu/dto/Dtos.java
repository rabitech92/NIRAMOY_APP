package com.tutorbondhu.dto;

import com.tutorbondhu.model.RequestStatus;
import com.tutorbondhu.model.Role;
import jakarta.validation.constraints.*;
import java.time.LocalDateTime;

public final class Dtos {
    private Dtos() {}

    public record RegisterRequest(@NotBlank String name, @NotBlank @Email String email,
                                  @NotBlank @Size(min = 6, message = "Password must be at least 6 characters") String password,
                                  String phone, @NotNull Role role) {}
    public record LoginRequest(@NotBlank @Email String email, @NotBlank String password) {}
    public record UserDto(Long id, String name, String email, String phone, Role role) {}
    public record AuthResponse(String token, UserDto user) {}

    public record TutorDto(Long id, String name, String subjects, String bio, int hourlyRate, String location, int experienceYears) {}
    public record TutorUpdate(@NotBlank String subjects, String bio, @Min(0) int hourlyRate, String location, @Min(0) int experienceYears) {}

    public record RequestCreate(@NotNull Long tutorId, @NotBlank String subject, String message) {}
    public record StatusUpdate(@NotNull RequestStatus status) {}
    public record AdminUserDto(Long id, String name, String email, String phone, Role role, boolean enabled) {}
    public record EnabledUpdate(boolean enabled) {}
    public record StatsDto(long totalUsers, long students, long tutors, long blockedUsers,
                           long totalRequests, long pending, long accepted, long rejected) {}
    public record RequestDto(Long id, String studentName, String tutorName, String subject, String message,
                             RequestStatus status, LocalDateTime createdAt) {}
}
