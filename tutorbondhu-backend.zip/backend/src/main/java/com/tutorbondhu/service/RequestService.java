package com.tutorbondhu.service;

import static com.tutorbondhu.dto.Dtos.*;

import com.tutorbondhu.exception.ApiException;
import com.tutorbondhu.model.*;
import com.tutorbondhu.repository.*;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

@Service @RequiredArgsConstructor
public class RequestService {
    private final TuitionRequestRepository requests;
    private final TutorProfileRepository tutors;
    private final UserRepository users;

    public RequestDto create(String email, RequestCreate r) {
        User student = users.findByEmail(email).orElseThrow(() -> new ApiException(HttpStatus.UNAUTHORIZED, "User not found"));
        TutorProfile tutor = tutors.findById(r.tutorId()).orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Tutor not found"));
        TuitionRequest t = new TuitionRequest();
        t.setStudent(student); t.setTutor(tutor); t.setSubject(r.subject().trim()); t.setMessage(r.message());
        return toDto(requests.save(t));
    }

    public List<RequestDto> mine(String email) {
        User u = users.findByEmail(email).orElseThrow(() -> new ApiException(HttpStatus.UNAUTHORIZED, "User not found"));
        var list = u.getRole() == Role.TUTOR
                ? requests.findByTutorUserEmailOrderByCreatedAtDesc(email)
                : requests.findByStudentEmailOrderByCreatedAtDesc(email);
        return list.stream().map(this::toDto).toList();
    }

    public RequestDto updateStatus(String email, Long id, RequestStatus status) {
        TuitionRequest t = requests.findById(id).orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Request not found"));
        if (!t.getTutor().getUser().getEmail().equals(email)) throw new ApiException(HttpStatus.FORBIDDEN, "Not your request");
        t.setStatus(status);
        return toDto(requests.save(t));
    }

    public RequestDto toDto(TuitionRequest t) {
        return new RequestDto(t.getId(), t.getStudent().getName(), t.getTutor().getUser().getName(), t.getSubject(), t.getMessage(), t.getStatus(), t.getCreatedAt());
    }
}
