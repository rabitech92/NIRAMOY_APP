package com.tutorbondhu.service;

import static com.tutorbondhu.dto.Dtos.*;

import com.tutorbondhu.exception.ApiException;
import com.tutorbondhu.model.*;
import com.tutorbondhu.repository.*;
import com.tutorbondhu.security.JwtService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service @RequiredArgsConstructor
public class AuthService {
    private final UserRepository users;
    private final TutorProfileRepository tutors;
    private final PasswordEncoder encoder;
    private final JwtService jwt;

    @Transactional
    public AuthResponse register(RegisterRequest r) {
        if (r.role() == Role.ADMIN) throw new ApiException(HttpStatus.BAD_REQUEST, "Invalid role");
        String email = r.email().trim().toLowerCase();
        if (users.existsByEmail(email)) throw new ApiException(HttpStatus.CONFLICT, "Email already registered");
        User u = new User();
        u.setName(r.name().trim()); u.setEmail(email); u.setPhone(r.phone());
        u.setPassword(encoder.encode(r.password())); u.setRole(r.role());
        users.save(u);
        if (u.getRole() == Role.TUTOR) { TutorProfile p = new TutorProfile(); p.setUser(u); tutors.save(p); }
        return new AuthResponse(jwt.generate(email), toDto(u));
    }

    public AuthResponse login(LoginRequest r) {
        User u = users.findByEmail(r.email().trim().toLowerCase())
                .filter(x -> encoder.matches(r.password(), x.getPassword()))
                .orElseThrow(() -> new ApiException(HttpStatus.UNAUTHORIZED, "Invalid email or password"));
        if (!u.isEnabled()) throw new ApiException(HttpStatus.FORBIDDEN, "Your account has been blocked");
        return new AuthResponse(jwt.generate(u.getEmail()), toDto(u));
    }

    private UserDto toDto(User u) { return new UserDto(u.getId(), u.getName(), u.getEmail(), u.getPhone(), u.getRole()); }
}
