package com.tutorbondhu.service;

import static com.tutorbondhu.dto.Dtos.*;

import com.tutorbondhu.exception.ApiException;
import com.tutorbondhu.model.*;
import com.tutorbondhu.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.*;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service @RequiredArgsConstructor
public class AdminService {
    private final UserRepository users;
    private final TuitionRequestRepository requests;
    private final TutorProfileRepository tutors;
    private final RequestService requestService;

    public StatsDto stats() {
        return new StatsDto(users.count(), users.countByRole(Role.STUDENT), users.countByRole(Role.TUTOR),
                users.countByEnabled(false), requests.count(), requests.countByStatus(RequestStatus.PENDING),
                requests.countByStatus(RequestStatus.ACCEPTED), requests.countByStatus(RequestStatus.REJECTED));
    }

    public Page<AdminUserDto> users(String q, Role role, int page, int size) {
        Pageable p = pageable(page, size);
        Page<User> r = role == null ? users.search(q.trim(), p) : users.searchByRole(q.trim(), role, p);
        return r.map(this::toDto);
    }

    public AdminUserDto setEnabled(Long id, boolean enabled) {
        User u = editable(id);
        u.setEnabled(enabled);
        return toDto(users.save(u));
    }

    @Transactional
    public void deleteUser(Long id) {
        User u = editable(id);
        requests.deleteByStudentId(id);
        if (u.getRole() == Role.TUTOR) { requests.deleteByTutorUserId(id); tutors.deleteByUserId(id); }
        users.delete(u);
    }

    public Page<RequestDto> requests(RequestStatus status, int page, int size) {
        Pageable p = pageable(page, size);
        Page<TuitionRequest> r = status == null ? requests.findAll(p) : requests.findByStatus(status, p);
        return r.map(requestService::toDto);
    }

    public void deleteRequest(Long id) {
        if (!requests.existsById(id)) throw new ApiException(HttpStatus.NOT_FOUND, "Request not found");
        requests.deleteById(id);
    }

    private User editable(Long id) {
        User u = users.findById(id).orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "User not found"));
        if (u.getRole() == Role.ADMIN) throw new ApiException(HttpStatus.BAD_REQUEST, "Admin accounts cannot be modified here");
        return u;
    }

    private Pageable pageable(int page, int size) {
        return PageRequest.of(Math.max(page, 0), Math.min(Math.max(size, 1), 100), Sort.by(Sort.Direction.DESC, "id"));
    }

    private AdminUserDto toDto(User u) {
        return new AdminUserDto(u.getId(), u.getName(), u.getEmail(), u.getPhone(), u.getRole(), u.isEnabled());
    }
}
