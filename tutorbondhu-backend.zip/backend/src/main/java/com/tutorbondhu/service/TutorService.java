package com.tutorbondhu.service;

import static com.tutorbondhu.dto.Dtos.*;

import com.tutorbondhu.exception.ApiException;
import com.tutorbondhu.model.TutorProfile;
import com.tutorbondhu.repository.TutorProfileRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.*;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

@Service @RequiredArgsConstructor
public class TutorService {
    private final TutorProfileRepository repo;

    public Page<TutorDto> search(String subject, String location, int page, int size) {
        Pageable p = PageRequest.of(Math.max(page, 0), Math.min(Math.max(size, 1), 50), Sort.by(Sort.Direction.DESC, "id"));
        return repo.search(subject.trim(), location.trim(), p).map(this::toDto);
    }

    public TutorDto get(Long id) {
        return repo.findById(id).map(this::toDto).orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Tutor not found"));
    }

    public TutorDto me(String email) { return toDto(mine(email)); }

    public TutorDto update(String email, TutorUpdate u) {
        TutorProfile p = mine(email);
        p.setSubjects(u.subjects().trim()); p.setBio(u.bio() == null ? "" : u.bio());
        p.setHourlyRate(u.hourlyRate()); p.setLocation(u.location() == null ? "" : u.location().trim());
        p.setExperienceYears(u.experienceYears());
        return toDto(repo.save(p));
    }

    private TutorProfile mine(String email) {
        return repo.findByUserEmail(email).orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Profile not found"));
    }

    private TutorDto toDto(TutorProfile t) {
        return new TutorDto(t.getId(), t.getUser().getName(), t.getSubjects(), t.getBio(), t.getHourlyRate(), t.getLocation(), t.getExperienceYears());
    }
}
