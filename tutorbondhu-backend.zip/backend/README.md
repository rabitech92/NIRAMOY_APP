# TutorBondhu API (Java 17, Spring Boot 3, MySQL)

Needs: JDK 17, Maven 3.9+, MySQL 8 on localhost:3306.

Defaults (override with env vars):
  DB_HOST=localhost  DB_NAME=tutorbondhu  DB_USER=root  DB_PASS=Admin123
  JWT_SECRET=<32+ chars>  ADMIN_EMAIL=admin@tutorbondhu.com  ADMIN_PASSWORD=Admin@12345

Run:
  mvn spring-boot:run          # http://localhost:8080/api
Build jar:
  mvn clean package && java -jar target/tutorbondhu-api-1.0.0.jar

Tables are created automatically on first start. An admin account is seeded.
Note: MySQL database names are case-sensitive on Linux; keep the same case everywhere.
